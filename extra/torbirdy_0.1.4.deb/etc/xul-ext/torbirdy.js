// Place your preferences for xul-ext-torbirdy in this file.
// You can override here the preferences specified in
// /usr/share/xul-ext/torbirdy/defaults/preferences/prefs.js
